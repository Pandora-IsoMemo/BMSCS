testing upload of model
