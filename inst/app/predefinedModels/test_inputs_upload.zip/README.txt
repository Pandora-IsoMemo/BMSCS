test upload of data and inputs
